#include "Dungeon.hh"

Dungeon::Hero::Hero(std::string n, unsigned int s, unsigned int hp)
{
	name = n;
	strength = s;
	health = hp;
}

Dungeon::Hero::Hero()
{
	
}
